class Dog :
  def __init__(self,name,age,breed,health ,hunger ):
    self.name = name
    self.age = age
    self.breed = breed
    self.health = health
    self.hunger = hunger
  def __str__(self): 
     return f"{self.name} {self.age} {self.breed} {self.health} {self.hunger}"
print("______HELLO AND WELCOME TO VIRTUAL-LIFE______")
print("you are ",)
name = "Barky"
print ("name:",name)
age =  5 
print ("age:",age)
health = 20
print ("you have  health :",health)
breed = "Chihuahua"
print ("Your breed is :",breed)
hunger = 0 
print ("your hunger:",hunger)
animal = Dog("Barky",0 ,5,20,"Chihuahua")

if input("Type 'begin' to start the game: ").strip().lower() == "begin":
    print("The game has started!") 
    print("hunger rate:")
    print(hunger+10)
user_choice = input("You Barky feel hungry with hunger amount. Type 'eat' to eat: ").strip().lower()

if user_choice == "eat":
    print("you are full now!")
    print("Well done you have eaten ... You are now ")
    print(age + 3)
else:
    print("Barky died out of hunger GAME OVER:(")


fight_choice = input("As you walk down the street you see little boys they attack you ...FAST !!! type *fight*: ").strip().lower()  
if fight_choice == "fight":
    print("you won !")
    print("Well done you have defeated them... You have health ")
    print(health + 10)
else :
    print("They defeated you GAME OVER :(" )

adopt_choice = input("A person saw you in the vet-shop, and wanted to adopt you,now he is training you type  *bark* to bark:").strip().lower()  
if  adopt_choice == "bark":
    print("you did it  !")
    print("Well done you barked... You have competed the game")
else :
    print("The adoption failed GAME OVER:(" )  